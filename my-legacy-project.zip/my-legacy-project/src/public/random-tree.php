<?php
session_start();

require __DIR__.'/../classes/Manager/TreesManager.php';

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}
?>

<html>
	<head>
		<title>Get a random tree in Paris</title>
	</head>
	<body>
		<ul>
			<li><a href = "dashboard.php">Go back to my dashboard</a></li>
		</ul>

		<h2>Get a random tree in Paris</h2>

		<button onClick = "window.location.reload();">Get a random tree</button>

		<table border = "1">
			<tr>
				<th>Gender</th>
				<th>Species</th>
				<th>Plantation date</th>
				<th>Address</th>
				<th>Height (meters)</th>
				<th>Our custom tree rating</th>
			</tr>
<?php
// Initialize TreesManager with data from json file
$treesManager = new TreesManager('../../data/arbresremarquablesparis2011.json');
$tree = $treesManager->getARandomTree();
?>
			<tr>
				<td><?=$tree['fields']['genre']?></td>
				<td><?=$tree['fields']['espece']?></td>
				<td><?=isset($tree['fields']['dateplantation']) ? $tree['fields']['dateplantation'] : '?'?></td>
				<td><?=$tree['fields']['adresse']?> (<?=$tree['fields']['arrondissement']?>)</td>
				<td><?=$tree['fields']['hauteurenm']?></td>
				<td><?=$treesManager->customTreeRating($tree['fields'])?></td>
			</tr>
	</body>
</html>