<?php
session_start();

require __DIR__.'/../classes/Manager/TreesManager.php';

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}
?>

<html>
	<head>
		<title>Outstanding trees in Paris</title>
	</head>
	<body>
		<ul>
			<li><a href = "dashboard.php">Go back to my dashboard</a></li>
		</ul>

		<h2>Outstanding trees in Paris</h2>
		<table border = "1">
			<tr>
				<th>Gender</th>
				<th>Species</th>
				<th>Plantation date</th>
				<th>Address</th>
				<th>Height (meters)</th>
				<th>Our custom tree rating</th>
			</tr>
<?php
// Initialize TreesManager with data from json file
$treesManager = new TreesManager('../../data/arbresremarquablesparis2011.json');
$sortedTrees = $treesManager->getSortedTrees();

// Add each tree to the table
foreach ($sortedTrees as $tree) {
?>
			<tr>
				<td><?=$tree['fields']['genre']?></td>
				<td><?=$tree['fields']['espece']?></td>
				<td><?=isset($tree['fields']['dateplantation']) ? $tree['fields']['dateplantation'] : '?'?></td>
				<td><?=$tree['fields']['adresse']?> (<?=$tree['fields']['arrondissement']?>)</td>
				<td><?=$tree['fields']['hauteurenm']?></td>
				<td><?=$treesManager->customTreeRating($tree['fields'])?></td>
			</tr>
<?php
}
?>
		</table>

		<p style = "font-size:10px">Data : <a href="https://opendata.paris.fr/explore/dataset/arbresremarquablesparis2011/information/">opendata.paris.fr</a></p>
	</body>
</html>