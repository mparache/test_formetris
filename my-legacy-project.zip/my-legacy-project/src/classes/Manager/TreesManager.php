<?php

class TreesManager {

    private $_trees = array();

    public function __construct($path) {
        $this->_trees = json_decode(file_get_contents($path), true);
        return;
    }

    public function getTrees() {
        return $this->_trees;
    }

    public function getSortedTrees() {
        $arrayA = array();
        $arrayB = array();
        $arrayC = array();

        foreach ($this->getTrees() as $tree) {
            $rating=$this->customTreeRating($tree['fields']);
            if ($rating == 'A') {
                $arrayA[] = $tree;
            }
            elseif ($rating == 'B') {
                $arrayB[] = $tree;
            }
            else {
                $arrayC[] = $tree;
            }
        }

        return(array_merge($arrayA, $arrayB, $arrayC));
    }

    public function customTreeRating($treeDetails) {
        if ($treeDetails['arrondissement'] == 'PARIS 18E ARRDT') {
            return 'C';
        }
        elseif (($treeDetails['hauteurenm'] * 100 + $treeDetails['circonferenceencm']) > 4000) {
            return 'A';
        }
        else {
            return 'B';
        }
    }

    public function getARandomTree() {
        $arrayA = array();
        $trees = $this->getTrees();
        foreach ($trees as $tree) {
            if ($this->customTreeRating($tree['fields']) == 'A') {
                $arrayA[] = $tree;
            }
        }
        return $arrayA[rand(0, sizeof($arrayA) - 1)];
    }
}