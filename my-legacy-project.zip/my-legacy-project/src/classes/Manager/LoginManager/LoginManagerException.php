<?php
namespace MyLegacyProject\Manager\LoginManager;

/**
 * Exception in case of login failure.
 * @author Bill
 *
 */
class LoginManagerException extends \Exception
{

}