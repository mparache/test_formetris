<?php
return array(
    array('username' => 'Admin', 'password' => '123456'),
    array('username' => 'Bill', 'password' => 'xxMySecretpaSSword!$$42'),
    array('username' => 'Toto', 'password' => '01012017'),
);